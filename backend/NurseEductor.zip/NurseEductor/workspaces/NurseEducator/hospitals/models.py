from ..app_template.hospitals.models import AbstractHospital


class Hospital(AbstractHospital):
    pass