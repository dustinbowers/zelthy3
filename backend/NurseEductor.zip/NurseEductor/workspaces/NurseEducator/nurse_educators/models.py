from ..app_template.nurse_educators.models import AbstractNurseEducator


class NurseEducator(AbstractNurseEducator):
    pass