from ...packages.crud.table.base import ModelTable

class SMSTransactionsTable(ModelTable):
    pass
