import { ReactComponent as Logo } from "../assets/Zelthy.svg";

export const HeaderLogo = <Logo />